<?php 

return [
    'en' => 'English',
    'fr' => 'Français',
    'ar' => 'عربى',
];  

?>