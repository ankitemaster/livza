<?php

namespace App\Http\Controllers\Admin;

use App\Models\Videochats;
use Illuminate\Http\Request;

class VideochatsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Videochats  $videochats
     * @return \Illuminate\Http\Response
     */
    public function show(Videochats $videochats)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Videochats  $videochats
     * @return \Illuminate\Http\Response
     */
    public function edit(Videochats $videochats)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Videochats  $videochats
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Videochats $videochats)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Videochats  $videochats
     * @return \Illuminate\Http\Response
     */
    public function destroy(Videochats $videochats)
    {
        //
    }
}
